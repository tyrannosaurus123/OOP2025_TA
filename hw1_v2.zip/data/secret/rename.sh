#!/bin/bash

cd /home/adduser/OOP_TA/testcases || { echo " 無法進入資料夾"; exit 1; }

count=1
for file in $(ls testcase_*.txt | sort); do
    newname="${count}.in"
    echo " $file → $newname"
    mv "$file" "$newname"
    ((count++))
done

echo " 所有 .txt 檔案已重新命名為 .in"
