#!/bin/bash

cd /home/adduser/OOP_TA/HW1_testcase || { echo "無法進入資料夾"; exit 1; }

for i in {2..19}; do
    filename="${i}.in"
    if [ -f "$filename" ]; then
        echo "移除 $filename 的第一行"
        sed -i '1d' "$filename"
    else
        echo "找不到 $filename，略過"
    fi
done

echo "已刪除 2.in ~ 19.in 的第一行"
